plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "com.potato.jarvis"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.potato.jarvis"
        minSdk = 26
        targetSdk = 35
        versionCode = 51
        versionName = "5.1"
    }

    buildFeatures {
        compose = true
        buildConfig = true
    }

    buildTypes {
        debug {
            buildConfigField("String", "DEFAULT_BACKEND_URL", "\"http://10.0.2.2:8000\"")
            buildConfigField("boolean", "ALLOW_HTTP_BACKEND", "true")
            buildConfigField("String", "POTATO_VERSION", "\"5.1\"")
        }
        release {
            buildConfigField("String", "DEFAULT_BACKEND_URL", "\"\"")
            buildConfigField("boolean", "ALLOW_HTTP_BACKEND", "false")
            buildConfigField("String", "POTATO_VERSION", "\"5.1\"")
        }
    }
}

dependencies {
    implementation(platform("androidx.compose:compose-bom:2025.02.00"))
    implementation("androidx.activity:activity-compose:1.10.1")
    implementation("androidx.activity:activity-ktx:1.10.1")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.9.7")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.9.7")
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.fragment:fragment-ktx:1.8.5")
    implementation("androidx.biometric:biometric:1.1.0")
    implementation("androidx.work:work-runtime-ktx:2.11.2")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.9.0")
    implementation("com.google.mlkit:text-recognition:16.0.1")
    debugImplementation("androidx.compose.ui:ui-tooling")
}
