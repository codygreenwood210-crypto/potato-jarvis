package com.potato.jarvis.accessibility

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent

/**
 * Reserved only for a future user-facing assistive feature. POTATO does not
 * expose arbitrary cross-app clicking, text injection, or screen scraping.
 */
class PotatoAccessibilityService : AccessibilityService() {
    override fun onAccessibilityEvent(event: AccessibilityEvent?) = Unit
    override fun onInterrupt() = Unit
}
