#!/usr/bin/env bash
#
# Verifies the Gradle wrapper the repository actually ships.
#
# Two supported modes:
#   JAR      - the official gradle-wrapper.jar is present; its SHA-256 must
#              match the pinned Gradle 8.9 value.
#   BOOTSTRAP - no JAR; ./gradlew is the POSIX bootstrap script, which must be
#              executable and must pin distributionSha256Sum.
#
# Either mode is a PASS. The failure case is a wrapper that can neither be
# checksum-verified nor executed.
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
JAR="$ROOT/gradle/wrapper/gradle-wrapper.jar"
PROPS="$ROOT/gradle/wrapper/gradle-wrapper.properties"
GRADLEW="$ROOT/gradlew"

EXPECTED_JAR="498495120a03b9a6ab5d155f5de3c8f0d986a449153702fb80fc80e134484f17"
EXPECTED_DIST="d725d707bfabd4dfdc958c624003b3c80accc03f7037b5122c4b1d0ef15cecab"

fail() { echo "GRADLE_WRAPPER=FAIL: $1" >&2; exit 1; }

[[ -f "$PROPS" ]] || fail "missing gradle/wrapper/gradle-wrapper.properties"

DIST_URL="$(sed -n 's/^[[:space:]]*distributionUrl[[:space:]]*=[[:space:]]*//p' "$PROPS" | tail -n 1 | sed 's/\\:/:/g')"
DIST_SHA="$(sed -n 's/^[[:space:]]*distributionSha256Sum[[:space:]]*=[[:space:]]*//p' "$PROPS" | tail -n 1 | tr -d '[:space:]')"

[[ -n "$DIST_URL" ]] || fail "distributionUrl is not set"
[[ -n "$DIST_SHA" ]] || fail "distributionSha256Sum is not pinned; an unverified distribution could be substituted"

if [[ "$DIST_SHA" != "$EXPECTED_DIST" ]]; then
  echo "GRADLE_WRAPPER=WARN: distributionSha256Sum does not match the known Gradle 8.9 bin checksum" >&2
  echo "  pinned:   $DIST_SHA" >&2
  echo "  gradle89: $EXPECTED_DIST" >&2
fi

if [[ -f "$JAR" ]]; then
  ACTUAL="$(sha256sum "$JAR" | awk '{print $1}')"
  if [[ "$ACTUAL" != "$EXPECTED_JAR" ]]; then
    echo "GRADLE_WRAPPER=FAIL: gradle-wrapper.jar checksum mismatch" >&2
    echo "  expected: $EXPECTED_JAR" >&2
    echo "  actual:   $ACTUAL" >&2
    exit 1
  fi
  echo "GRADLE_WRAPPER=PASS mode=JAR: official Gradle 8.9 wrapper checksum matched"
  exit 0
fi

# No JAR: validate the bootstrap script instead.
[[ -f "$GRADLEW" ]] || fail "no gradle-wrapper.jar and no ./gradlew"
[[ -x "$GRADLEW" ]] || fail "./gradlew is not executable (run: chmod +x gradlew)"
sh -n "$GRADLEW" || fail "./gradlew has a shell syntax error"
grep -q 'distributionSha256Sum' "$GRADLEW" || fail "./gradlew does not verify distributionSha256Sum"

case "$DIST_URL" in
  https://services.gradle.org/*|https://downloads.gradle.org/*) ;;
  *) fail "distributionUrl is not an official Gradle host: $DIST_URL" ;;
esac

echo "GRADLE_WRAPPER=PASS mode=BOOTSTRAP: ./gradlew verifies the pinned distribution checksum"
echo "  distribution: $DIST_URL"
echo "  sha256:       $DIST_SHA"
echo "  note: to switch to the official binary wrapper, run"
echo "        gradle wrapper --gradle-version 8.9 --distribution-type bin"
