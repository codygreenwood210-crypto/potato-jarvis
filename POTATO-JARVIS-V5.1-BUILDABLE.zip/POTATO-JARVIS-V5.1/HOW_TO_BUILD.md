# How to actually build POTATO-JARVIS (phone-only route)

The final audit says NOT PRODUCTION READY for one reason: nobody has run a real
Android build. The code has never been compiled by a real Android toolchain, so
`assembleDebug`, lint, packaging, and device install are all unproven.

You do not need a computer to fix that. GitHub Actions runners have network
access and ship the Android SDK preinstalled. Pushing this repo to GitHub runs
a real build and hands you an installable APK.

---

## Step 1 — Get the repo onto GitHub

From the GitHub mobile app or the website:

1. Create a new **private** repository, e.g. `potato-jarvis`.
2. Upload the contents of this archive (the files at the level of `README.md`,
   not the folder wrapping them).

If uploading through the web UI, note that it will not preserve the executable
bit on `gradlew`. Fix it once from the repo's web editor is not possible, so
instead add this as the first step of the android job if the build fails with
"Permission denied": `run: chmod +x gradlew scripts/*.sh`. The workflow below
already tolerates this because `verify_gradle_wrapper.sh` will tell you plainly
that `./gradlew` is not executable.

The cleanest alternative is to use a git client app (Working Copy on iOS,
Termux + git on Android), which preserves file modes.

## Step 2 — Run the workflow

`.github/workflows/ci.yml` has three jobs and a `workflow_dispatch` trigger, so
you can start it by hand from the Actions tab.

| Job | What it proves |
|---|---|
| `backend` | Installs deps, runs `compileall` and all 98 pytest tests |
| `android` | **Runs `:android:assembleDebug`** — this is the finding F-002 gate — then lint, and uploads the APK |
| `gradle-wrapper-jar` | Generates the official `gradle-wrapper.jar`, verifies its SHA-256 against Gradle's published value, uploads it |

Lint runs with `continue-on-error`, so a lint warning cannot cost you the APK.
The lint HTML report uploads either way.

## Step 3 — Collect the results

On the finished workflow run page, scroll to **Artifacts**:

- `potato-debug-apk` — download on your phone and install it. Android will ask
  you to allow installs from unknown sources.
- `gradle-wrapper-jar` — commit this to `gradle/wrapper/gradle-wrapper.jar`.
  Once committed, `./scripts/verify_gradle_wrapper.sh` switches from
  `mode=BOOTSTRAP` to `mode=JAR` and finding F-003 closes.
- `android-lint-report` — read this before calling anything production ready.

The debug build points at `http://10.0.2.2:8000`, which is the emulator's alias
for your host machine. On a physical phone, open Settings in the app and enter
your backend's real address.

## Step 4 — What is still not done after this

Getting a green `assembleDebug` closes F-002 and proves the source compiles. It
does **not** close these:

- **Signed release build.** `android/build.gradle.kts` has no `signingConfig`,
  so `assembleRelease` would emit an unsigned APK. You need to generate a
  keystore, add a `signingConfig` block reading from environment variables, and
  store the keystore as a base64 repository secret. Never commit a keystore.
- **Physical-device regression.** Camera capture, `SpeechRecognizer`/TTS
  lifecycle, biometric approval via Android Keystore, `WorkManager` diagnostics,
  and the notification permission flow can only be verified on a real device.
  The biometric approval path in particular is the security control the whole
  risk-3 model rests on, and it has never been executed.
- **Live integrations.** No OpenAI call and no Home Assistant call has ever run.

## Step 5 — Backend

The backend is the verified half. On any machine or a cheap VPS:

```bash
python3 -m venv .venv && . .venv/bin/activate
pip install -r backend/requirements.txt
cp backend/.env.example backend/.env
# set OPENAI_API_KEY and a POTATO_API_TOKEN of 32+ characters
./backend/run.sh
```

For anything reachable from outside your own network, set `POTATO_ENV=production`
and put it behind HTTPS. In production the backend now refuses a non-HTTPS
`OPENAI_BASE` and rejects anonymous mode outright.
