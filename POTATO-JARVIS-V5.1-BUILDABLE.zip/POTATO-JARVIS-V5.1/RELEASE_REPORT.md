# POTATO-JARVIS V5.1 Release Gate

## Implemented in V5.1
- Retains the V5.0 integrated feature set and security controls.
- Adds production validation that `OPENAI_BASE` must use HTTPS, preventing accidental API-key transmission to a plaintext HTTP AI endpoint.
- Adds regression tests for production AI-provider URL security.
- Corrects active version metadata to 5.1 / Android versionCode 51.
- Corrects stale active API/README version labels.
- Preserves the pinned Gradle 8.9 distribution SHA-256 and bootstrap-wrapper verification.

## Executed verification in this environment
- ZIP integrity: PASS.
- Python `compileall`: PASS.
- Backend tests: 98 PASSED.
- Android XML parse: PASS (9 files).
- Gradle wrapper verifier: PASS in BOOTSTRAP mode.
- Android `assembleDebug` + `lint`: BLOCKED because this sandbox cannot resolve `services.gradle.org` and has no Android SDK configured.
- Physical-device install/runtime: NOT EXECUTED.
- Release signing: NOT EXECUTED.
- Live OpenAI/Home Assistant integrations: NOT EXECUTED.
- Windows `gradlew.bat`: NOT EXECUTED.

## Release status
**NOT PRODUCTION READY.**

The backend is test-verified in this environment, but Android compilation/lint, signed-release generation, and physical-device regression remain release-blocking verification gates.
