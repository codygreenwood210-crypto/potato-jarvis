@echo off
@rem POTATO self-bootstrapping Gradle wrapper (Windows).
@rem Mirrors ./gradlew: reads gradle\wrapper\gradle-wrapper.properties, downloads
@rem the pinned distribution, verifies its SHA-256, unpacks it, and runs Gradle.
setlocal

set "APP_HOME=%~dp0"
set "PROPS=%APP_HOME%gradle\wrapper\gradle-wrapper.properties"

if not exist "%PROPS%" (
  echo POTATO gradlew: missing %PROPS% 1>&2
  exit /b 1
)

if defined JAVA_HOME (
  if exist "%JAVA_HOME%\bin\java.exe" goto javaok
)
where java >nul 2>nul
if %ERRORLEVEL% NEQ 0 (
  echo POTATO gradlew: no Java runtime found. Install JDK 17 or newer, or set JAVA_HOME. 1>&2
  exit /b 1
)
:javaok

powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$ErrorActionPreference='Stop';" ^
  "$props=@{}; Get-Content -LiteralPath $env:PROPS | ForEach-Object { if ($_ -match '^\s*([^#=]+?)\s*=\s*(.*?)\s*$') { $props[$Matches[1]] = $Matches[2] -replace '\\:',':' } };" ^
  "$url=$props['distributionUrl']; $sha=$props['distributionSha256Sum'];" ^
  "if (-not $url) { throw 'distributionUrl is not set' };" ^
  "if ($props['validateDistributionUrl'] -ne 'false' -and $url -notmatch '^(https://services\.gradle\.org/|https://downloads\.gradle\.org/|file:)') { throw \"refusing to download from untrusted distributionUrl: $url\" };" ^
  "$file=[IO.Path]::GetFileName($url); $base=[IO.Path]::GetFileNameWithoutExtension($file);" ^
  "$ver=$base -replace '^gradle-','' -replace '-(bin|all)$','';" ^
  "$guh=if ($env:GRADLE_USER_HOME) { $env:GRADLE_USER_HOME } else { Join-Path $env:USERPROFILE '.gradle' };" ^
  "$tag=[BitConverter]::ToString([Security.Cryptography.SHA256]::Create().ComputeHash([Text.Encoding]::UTF8.GetBytes($url))).Replace('-','').Substring(0,8).ToLower();" ^
  "$dir=Join-Path $guh \"wrapper\dists\$base\potato-$tag\"; $home=Join-Path $dir \"gradle-$ver\";" ^
  "$bat=Join-Path $home 'bin\gradle.bat';" ^
  "if (-not (Test-Path -LiteralPath $bat)) {" ^
  "  New-Item -ItemType Directory -Force -Path $dir | Out-Null;" ^
  "  $zip=Join-Path $dir $file;" ^
  "  if (-not (Test-Path -LiteralPath $zip)) {" ^
  "    Write-Host \"POTATO gradlew: downloading $url\";" ^
  "    $tmp=\"$zip.part\"; Invoke-WebRequest -Uri $url -OutFile $tmp -UseBasicParsing; Move-Item -Force $tmp $zip };" ^
  "  if ($sha) {" ^
  "    $actual=(Get-FileHash -LiteralPath $zip -Algorithm SHA256).Hash.ToLower();" ^
  "    if ($actual -ne $sha.ToLower()) { Remove-Item -Force $zip; throw \"SHA-256 MISMATCH for $file`n  expected: $sha`n  actual:   $actual\" } }" ^
  "  else { Write-Host 'POTATO gradlew: WARNING - distributionSha256Sum is not pinned.' };" ^
  "  Expand-Archive -LiteralPath $zip -DestinationPath $dir -Force };" ^
  "if (-not (Test-Path -LiteralPath $bat)) { throw \"gradle launcher not found at $bat\" };" ^
  "Set-Content -LiteralPath (Join-Path $env:TEMP 'potato-gradle-home.txt') -Value $bat"

if %ERRORLEVEL% NEQ 0 exit /b %ERRORLEVEL%

set /p GRADLE_BAT=<"%TEMP%\potato-gradle-home.txt"
del "%TEMP%\potato-gradle-home.txt" >nul 2>nul
call "%GRADLE_BAT%" %*
exit /b %ERRORLEVEL%
