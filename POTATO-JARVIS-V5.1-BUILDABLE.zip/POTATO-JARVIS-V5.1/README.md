# POTATO-JARVIS V5.1

Current integrated source milestone: V5.1. See `RELEASE_REPORT.md` for verification gates and known blockers.

# POTATO JARVIS V4.9

POTATO is a security-first Android personal AI assistant with a server-side AI brain. V4.9 hardens and formalizes the integrated JARVIS Core release of the existing roadmap implementation: conversation, identity/context, long-term memory, tools, security/approvals, planning/orchestration, verification-oriented execution, web search, vision, file intelligence, voice, reserved accessibility surface (no arbitrary cross-app control), automations, smart-device adapters, multi-agent roles, diagnostics, audit tracing, and failure handling.

## Architecture

- **Android:** Jetpack Compose UI, lifecycle-aware state collection, local SQLite history/settings, Android Keystore token protection, SpeechRecognizer/TTS, camera capture through FileProvider, biometric approvals, WorkManager diagnostics, and an opt-in AccessibilityService surface that is intentionally non-controlling.
- **Backend:** FastAPI, SQLite persistence, OpenAI Responses API, function tools, web search, vision, planner, orchestrator, security gateway, exact-argument approvals, audit traces, document extraction, automations, device adapters, and specialized agent roles.
- **Security:** the model is never the authority. Risk 0–1 actions may execute automatically; risk 2–3 require explicit approval; risk 3 also requires device authentication in the Android UI; risk 4 is denied. Approval hashes are bound to the exact normalized arguments and expire after 15 minutes. Risk-3 approvals additionally require a server-verified signature from a biometric-gated Android Keystore key.
- **Secrets:** OpenAI credentials remain server-side. Android API tokens are stored with Android Keystore encryption rather than plaintext SQLite.

## AI provider

The backend uses the OpenAI Responses API. The default model is `gpt-5.6-luna`. The default provider is configured for the OpenAI Responses API. Model capabilities and availability should be verified against the current OpenAI model catalog before deployment.

## Backend

```bash
python3 -m venv .venv
. .venv/bin/activate
pip install -r backend/requirements.txt
cp backend/.env.example backend/.env
# set OPENAI_API_KEY and a strong POTATO_API_TOKEN for deployment
./backend/run.sh
```

The backend is a Python package and is intentionally launched from the repository root as `backend.main:app`. This keeps module imports consistent for local development, tests, and process managers.

Authentication is required by default. For isolated local development only, set `POTATO_ALLOW_ANONYMOUS=true`.

### Environment

- `OPENAI_API_KEY`: server-side OpenAI credential.
- `OPENAI_MODEL`: defaults to `gpt-5.6-luna`.
- `OPENAI_BASE`: defaults to `https://api.openai.com/v1`.
- `OPENAI_TIMEOUT_SECONDS`: provider timeout, default 120 seconds.
- `POTATO_API_TOKEN`: bearer token for private API access.
- `POTATO_ALLOW_ANONYMOUS`: explicit local-development escape hatch; default false.
- `POTATO_ALLOW_PRIVATE_DEVICE_NETWORKS`: enable only when smart devices intentionally live on private/loopback networks.
- `POTATO_HOME`, `POTATO_DB`, `POTATO_NOTES`, `POTATO_FILES`: storage locations.
- `HOST`, `PORT`: server bind configuration.

## Android

Open the repository in Android Studio. The debug build permits cleartext HTTP for local emulator/LAN development; the production manifest disables cleartext traffic, so production deployments should use HTTPS.

The UI contains Chat, Memory, Tasks, Notifications, Device, Tools, Security, and Settings. Chat supports text, optional web search, voice input/output, camera vision, loading/error states, and automatic scroll-to-latest-message. Memory supports search and saving. Tasks create and execute dependency-checked plans. Tools exposes the backend catalog and file intelligence. Security exposes exact approvals and biometric authentication for high-risk actions. Settings configures the backend and explains that unrestricted cross-app control is not enabled.

Android uses Compose state-hoisting/unidirectional data flow, lifecycle-aware state collection, WorkManager for deferrable diagnostics, and lifecycle-scoped voice/camera resources.

## API surface

The unified JARVIS Core entry point is `/v1/agent/run`; the older specialized endpoints remain available for compatibility and focused UI flows.

- `/v1/health`
- `/v1/diagnostics`
- `/v1/sessions`
- `/v1/sessions/{session_id}/messages`
- `/v1/memory`
- `/v1/preferences`
- `/v1/tools`
- `/v1/tools/validate`
- `/v1/agent/run`
- `/v1/chat`
- `/v1/plan`
- `/v1/plan/execute`
- `/v1/tasks/{task_id}`
- `/v1/tasks/{task_id}/cancel`
- `/v1/approvals`
- `/v1/approvals/{approval_id}/challenge`
- `/v1/security/device-key`
- `/v1/trace`
- `/v1/files`
- `/v1/vision`
- `/v1/agents`
- `/v1/automations`
- `/v1/devices`
- `/v1/devices/action`
- `/v1/notes`

## JARVIS Core trace contract

Every `/v1/agent/run` request receives one root `trace_id`. Chat model calls, security decisions, tool runs, approvals, planner creation, task execution, and completion audits reuse that trace. Stored plans retain the originating trace so approval resumes remain correlated with the original request. Plan-mode runs also persist a concise assistant summary into the session history.

## Verification

The repository includes a backend verification script:

```bash
./scripts/verify_backend.sh
```

The backend test suite covers health/schema creation, authentication, memory/preferences/sessions, tool schema validation, chat persistence, path safety, file upload/read/delete, exact-argument approvals, planner dependency validation, approval-driven plan resume, automations, device security, diagnostics/traces, provider failure handling, and Responses-style function-call round trips.

### Gradle wrapper

The repository does not carry the official `gradle-wrapper.jar` binary. Instead, `gradlew` and `gradlew.bat` are self-bootstrapping scripts that do what the wrapper JAR does: read `gradle/wrapper/gradle-wrapper.properties`, download the pinned Gradle 8.9 distribution, verify its SHA-256 against `distributionSha256Sum`, unpack it into the Gradle user home, and exec the real launcher. A checksum mismatch deletes the download and aborts. Distribution URLs outside `services.gradle.org` / `downloads.gradle.org` are refused. If a system `gradle` matching the pinned version is already on `PATH`, it is used and nothing is downloaded.

```bash
./scripts/verify_gradle_wrapper.sh   # PASS in JAR mode or BOOTSTRAP mode
./gradlew :android:assembleDebug
```

To switch to the official binary wrapper instead, run `gradle wrapper --gradle-version 8.9 --distribution-type bin` once on a machine that has Gradle installed and commit the resulting JAR; `verify_gradle_wrapper.sh` will then checksum it against the published Gradle 8.9 value.

The first build still requires network access to `services.gradle.org` (for Gradle) and to `google()` / `mavenCentral()` (for the Android Gradle Plugin and AndroidX), plus an installed Android SDK with platform 35. Kotlin sources were parser-checked with `kotlinc`; the compiler's remaining diagnostics are dependency-resolution failures caused by the absent Android/AndroidX SDK/classpath, not Kotlin syntax errors.

## Security notes

- Do not put `OPENAI_API_KEY` in the APK.
- Use HTTPS outside isolated local development.
- Use a strong `POTATO_API_TOKEN` in deployment.
- Private/loopback device networks are blocked by default; explicitly enable them only for intentional smart-home deployments.
- External web/document content is untrusted data.
- Approval decisions are bound to exact normalized tool arguments.
- Destructive and device-control operations cannot self-authorize.
- Audit/security/tool-run traces are retained in SQLite for diagnostics and review.

## V4.7 device context

POTATO can display local battery, network, device/app information, and optional calendar/contact/location context after explicit runtime permission. Clipboard text is read only after an explicit user action. This local context is not automatically uploaded to the backend. Unrestricted cross-app control remains disabled; configured server-side device actions retain the existing approval/security boundary.
